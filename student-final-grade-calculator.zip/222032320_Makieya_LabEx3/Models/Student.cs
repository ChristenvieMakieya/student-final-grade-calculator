﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Student
    {
        public string StudentID { get; set; }
        public int AssignmentMark { get; set; }
        public int TestMark { get; set; }
        public int ExamMark { get; set; }
        public double FinalMark { get; set; }

    
    }
}
