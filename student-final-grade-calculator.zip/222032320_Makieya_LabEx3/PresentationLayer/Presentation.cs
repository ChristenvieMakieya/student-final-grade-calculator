﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogicLayer;
using Models;

namespace PresentationLayer
{
    class Presentation
    {
        static BLL manager = new BLL();

        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("--- Student Marks Application ---");
                Console.WriteLine("1. Add Student Marks");
                Console.WriteLine("2. View All Students and Final Marks");
                Console.WriteLine("3. Exit");
                Console.Write("Select an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        ViewStudents();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }

                Console.WriteLine("\nPress Enter to continue...");
                Console.ReadLine();
            }
        }

        static void AddStudent()
        {
            Student student = new Student();

            Console.Write("Enter Student ID: ");
            student.StudentID = Console.ReadLine();

            student.AssignmentMark = GetMark("Assignment Mark (0-100): ");
            student.TestMark = GetMark("Test Mark (0-100): ");
            student.ExamMark = GetMark("Exam Mark (0-100): ");

            manager.AddStudent(student);
            Console.WriteLine("Student added successfully.");
        }

        static int GetMark(string prompt)
        {
            int mark;
            do
            {
                Console.Write(prompt);
            } while (!int.TryParse(Console.ReadLine(), out mark) || mark < 0 || mark > 100);
            return mark;
        }

        static void ViewStudents()
        {
            var students = manager.GetAllStudents();
            Console.WriteLine("\nStudent Records:");
            foreach (var student in students)
            {
                Console.WriteLine($"ID: {student.StudentID} | Final Mark: {student.FinalMark:F2}");
            }
        }
    }

}
