CREATE DATABASE StudentsDB;
USE StudentsDB;

CREATE TABLE Students(
	StudentID INT PRIMARY KEY, 
	AssignmentMark DECIMAL, 
	TestMark DECIMAL, 
	ExamMark DECIMAL,
	FinalMark DECIMAL);

SELECT * FROM Students;