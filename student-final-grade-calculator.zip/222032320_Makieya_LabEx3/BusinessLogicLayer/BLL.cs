﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using Models;

namespace BusinessLogicLayer
{
    public class BLL
    {
        private readonly DLL db = new DLL();

        public double CalculateFinalMark(int assignment, int test, int exam)
        {
            return (assignment * 0.30) + (test * 0.30) + (exam * 0.40);
        }

        public void AddStudent(Student student)
        {
            student.FinalMark = CalculateFinalMark(student.AssignmentMark, student.TestMark, student.ExamMark);
            db.InsertStudent(student);
        }

        public List<Student> GetAllStudents()
        {
            return db.GetStudents();
        }
    }

}
