﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;


namespace DataAccessLayer
{

    public class DLL
    {
        private readonly string connectionString = @"Data Source=DESKTOP-TBCRTLN\SQLEXPRESS01;Initial Catalog=StudentsDB;Integrated Security=True";

        public void InsertStudent(Student student)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Students (StudentID, AssignmentMark, TestMark, ExamMark, FinalMark) " +
                               "VALUES (@StudentID, @AssignmentMark, @TestMark, @ExamMark, @FinalMark)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@StudentID", student.StudentID);
                cmd.Parameters.AddWithValue("@AssignmentMark", student.AssignmentMark);
                cmd.Parameters.AddWithValue("@TestMark", student.TestMark);
                cmd.Parameters.AddWithValue("@ExamMark", student.ExamMark);
                cmd.Parameters.AddWithValue("@FinalMark", student.FinalMark);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Student> GetStudents()
        {
            List<Student> students = new List<Student>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Students";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    students.Add(new Student
                    {
                        StudentID = reader["StudentID"].ToString(),
                        AssignmentMark = Convert.ToInt32(reader["AssignmentMark"]),
                        TestMark = Convert.ToInt32(reader["TestMark"]),
                        ExamMark = Convert.ToInt32(reader["ExamMark"]),
                        FinalMark = Convert.ToDouble(reader["FinalMark"])
                    });
                }
            }

            return students;
            ;
        }
    }
}
